﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Text;
using UnityEngine;
using Verse;
using Verse.AI;
using RimWorld;
using HarmonyLib;

namespace VFECore
{

    public static class Patch_DualWield_Ext_Pawn_EquipmentTracker
    {

        public static class manual_MakeRoomForOffHand
        {

            public static void Postfix(Pawn_EquipmentTracker instance, ThingWithComps eq)
            {
                if (instance.OffHandShield() != null)
                    ShieldUtility.MakeRoomForShield(instance, eq);
            }

        }

    }

}
